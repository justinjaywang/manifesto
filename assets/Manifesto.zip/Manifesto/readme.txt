Manifesto is a display typeface inspired by Ken Garland’s 1964 First Things First manifesto.

Designed by Justin Jay Wang (@justinjaywang) in the summer of 2016. Use at large sizes, with plenty of whitespace.
